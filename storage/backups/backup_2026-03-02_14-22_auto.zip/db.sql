SET NAMES utf8mb4;
SET foreign_key_checks = 0;

-- Table: `batches`
DROP TABLE IF EXISTS `batches`;
CREATE TABLE `batches` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fish_type` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `lot_number` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `production_date` date NOT NULL,
  `expiration_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lot_number` (`lot_number`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `batches` (`id`,`fish_type`,`lot_number`,`production_date`,`expiration_date`,`created_at`) VALUES (37,'SGOMBRO',35.26,'2026-03-02','2026-03-05','2026-03-02 09:54:39');
INSERT INTO `batches` (`id`,`fish_type`,`lot_number`,`production_date`,`expiration_date`,`created_at`) VALUES (38,'TONNO',31.26,'2026-03-02','2026-03-01','2026-03-02 09:55:08');
INSERT INTO `batches` (`id`,`fish_type`,`lot_number`,`production_date`,`expiration_date`,`created_at`) VALUES (39,'TONNO',30.26,'2026-03-02','2026-02-28','2026-03-02 10:04:48');
INSERT INTO `batches` (`id`,`fish_type`,`lot_number`,`production_date`,`expiration_date`,`created_at`) VALUES (40,'SGOMBRO',40,'2026-03-02','2026-03-11','2026-03-02 10:27:06');
INSERT INTO `batches` (`id`,`fish_type`,`lot_number`,`production_date`,`expiration_date`,`created_at`) VALUES (41,'TONNO',355,'2026-03-02','2026-03-02','2026-03-02 10:29:48');
INSERT INTO `batches` (`id`,`fish_type`,`lot_number`,`production_date`,`expiration_date`,`created_at`) VALUES (42,'SGOMBRO',737,'2026-03-02','2030-10-02','2026-03-02 10:31:51');
INSERT INTO `batches` (`id`,`fish_type`,`lot_number`,`production_date`,`expiration_date`,`created_at`) VALUES (43,'TONNO',899,'2026-03-02','2029-06-20','2026-03-02 10:36:32');
INSERT INTO `batches` (`id`,`fish_type`,`lot_number`,`production_date`,`expiration_date`,`created_at`) VALUES (44,'SGOMBRO',42,'2026-03-02','2026-12-18','2026-03-02 12:00:00');

-- Table: `lots`
DROP TABLE IF EXISTS `lots`;
CREATE TABLE `lots` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `batch_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id` (`product_id`,`batch_id`),
  KEY `batch_id` (`batch_id`),
  CONSTRAINT `lots_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `lots_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `batches` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `lots` (`id`,`product_id`,`batch_id`,`created_at`) VALUES (52,39,37,'2026-03-02 09:54:39');
INSERT INTO `lots` (`id`,`product_id`,`batch_id`,`created_at`) VALUES (53,38,38,'2026-03-02 09:55:08');
INSERT INTO `lots` (`id`,`product_id`,`batch_id`,`created_at`) VALUES (54,38,39,'2026-03-02 10:04:48');
INSERT INTO `lots` (`id`,`product_id`,`batch_id`,`created_at`) VALUES (55,39,40,'2026-03-02 10:27:06');
INSERT INTO `lots` (`id`,`product_id`,`batch_id`,`created_at`) VALUES (56,38,41,'2026-03-02 10:29:48');
INSERT INTO `lots` (`id`,`product_id`,`batch_id`,`created_at`) VALUES (57,39,42,'2026-03-02 10:31:51');
INSERT INTO `lots` (`id`,`product_id`,`batch_id`,`created_at`) VALUES (58,38,43,'2026-03-02 10:36:32');
INSERT INTO `lots` (`id`,`product_id`,`batch_id`,`created_at`) VALUES (59,40,41,'2026-03-02 11:18:13');
INSERT INTO `lots` (`id`,`product_id`,`batch_id`,`created_at`) VALUES (60,39,44,'2026-03-02 12:00:00');

-- Table: `movements`
DROP TABLE IF EXISTS `movements`;
CREATE TABLE `movements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `lot_id` int NOT NULL,
  `quantity` int NOT NULL,
  `type` enum('PRODUCTION','SALE','ADJUSTMENT') COLLATE utf8mb4_general_ci NOT NULL,
  `reason` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `note` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `lot_id` (`lot_id`),
  CONSTRAINT `movements_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `movements_ibfk_2` FOREIGN KEY (`lot_id`) REFERENCES `lots` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (1,39,52,24,'PRODUCTION',NULL,NULL,'2026-03-02 09:54:39');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (2,38,53,48,'PRODUCTION',NULL,NULL,'2026-03-02 09:55:08');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (3,39,52,1,'SALE',NULL,NULL,'2026-03-02 09:55:34');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (4,39,52,1,'SALE',NULL,NULL,'2026-03-02 09:56:00');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (5,39,52,1,'SALE',NULL,NULL,'2026-03-02 09:56:46');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (6,38,53,1,'PRODUCTION',NULL,NULL,'2026-03-02 10:02:09');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (7,38,54,24,'PRODUCTION',NULL,NULL,'2026-03-02 10:04:48');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (8,38,54,1,'ADJUSTMENT','ROTTURA',NULL,'2026-03-02 10:06:01');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (9,39,55,24,'PRODUCTION',NULL,NULL,'2026-03-02 10:27:06');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (10,38,56,48,'PRODUCTION',NULL,NULL,'2026-03-02 10:29:48');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (11,38,56,48,'PRODUCTION',NULL,NULL,'2026-03-02 10:30:47');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (12,39,57,12,'PRODUCTION',NULL,NULL,'2026-03-02 10:31:51');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (13,38,58,48,'PRODUCTION',NULL,NULL,'2026-03-02 10:36:32');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (14,38,56,1,'SALE',NULL,NULL,'2026-03-02 10:41:31');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (15,39,52,1,'SALE',NULL,NULL,'2026-03-02 10:42:10');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (16,38,58,1,'SALE',NULL,NULL,'2026-03-02 10:42:53');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (17,38,56,1,'SALE',NULL,NULL,'2026-03-02 10:43:23');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (18,38,56,1,'SALE',NULL,NULL,'2026-03-02 10:43:37');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (19,39,52,1,'SALE',NULL,NULL,'2026-03-02 10:55:49');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (20,38,56,1,'SALE',NULL,NULL,'2026-03-02 10:55:55');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (21,38,56,1,'SALE',NULL,NULL,'2026-03-02 11:00:13');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (22,38,54,1,'PRODUCTION',NULL,NULL,'2026-03-02 11:15:24');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (23,38,54,1,'PRODUCTION',NULL,NULL,'2026-03-02 11:15:33');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (24,38,53,1,'PRODUCTION',NULL,NULL,'2026-03-02 11:15:37');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (25,38,56,1,'PRODUCTION',NULL,NULL,'2026-03-02 11:16:09');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (26,40,59,12,'PRODUCTION',NULL,NULL,'2026-03-02 11:18:13');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (27,40,59,1,'PRODUCTION',NULL,NULL,'2026-03-02 11:18:40');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (28,40,59,1,'PRODUCTION',NULL,NULL,'2026-03-02 11:18:44');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (29,38,56,1,'PRODUCTION',NULL,NULL,'2026-03-02 11:18:47');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (30,38,56,1,'PRODUCTION',NULL,NULL,'2026-03-02 11:18:50');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (31,38,56,1,'ADJUSTMENT','INVENTARIO',NULL,'2026-03-02 11:29:56');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (32,39,60,24,'PRODUCTION',NULL,NULL,'2026-03-02 12:00:00');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (33,39,57,24,'PRODUCTION',NULL,NULL,'2026-03-02 12:49:18');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (34,40,59,1,'SALE',NULL,NULL,'2026-03-02 12:49:38');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (35,40,59,1,'SALE',NULL,NULL,'2026-03-02 12:49:57');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (36,38,56,1,'SALE',NULL,NULL,'2026-03-02 12:50:47');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (37,38,58,1,'SALE',NULL,NULL,'2026-03-02 12:51:00');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (38,38,56,1,'SALE',NULL,NULL,'2026-03-02 12:51:32');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (39,38,58,1,'SALE',NULL,NULL,'2026-03-02 12:51:45');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (40,38,56,1,'SALE',NULL,NULL,'2026-03-02 12:51:55');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (41,39,52,1,'SALE',NULL,NULL,'2026-03-02 12:52:09');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (42,40,59,1,'SALE',NULL,NULL,'2026-03-02 13:47:59');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (43,40,59,1,'SALE',NULL,NULL,'2026-03-02 13:48:05');

-- Table: `products`
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `format` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `fish_type` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `ean` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `units_per_tray` int NOT NULL,
  `image_path` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ean` (`ean`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `products` (`id`,`name`,`format`,`fish_type`,`ean`,`units_per_tray`,`image_path`,`created_at`,`is_active`) VALUES (38,'Tonno Olio di oliva','100gr','TONNO',8001234567891,24,NULL,'2026-03-01 02:10:13',1);
INSERT INTO `products` (`id`,`name`,`format`,`fish_type`,`ean`,`units_per_tray`,`image_path`,`created_at`,`is_active`) VALUES (39,'Sgombro olio d\'oliva',200,'SGOMBRO',800232,12,NULL,'2026-03-01 21:32:45',1);
INSERT INTO `products` (`id`,`name`,`format`,`fish_type`,`ean`,`units_per_tray`,`image_path`,`created_at`,`is_active`) VALUES (40,'Tonno Olio di oliva','200g','TONNO',213231,12,NULL,'2026-03-02 11:16:38',1);

-- Table: `settings`
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `settings_json` json NOT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `settings` (`id`,`settings_json`,`updated_at`) VALUES (1,'{\"backup_time\": \"14:22\", \"backup_enabled\": true, \"backup_frequency\": \"daily\", \"backup_keep_last\": 14, \"backup_auto_prune\": true, \"sale_default_mode\": \"FEFO\", \"backup_environment\": \"local\", \"backup_include_uploads\": true, \"low_stock_alert_enabled\": true, \"scanner_beep_on_success\": false, \"scanner_vibrate_on_error\": false, \"expiry_alert_general_days\": 30, \"expiry_include_zero_stock\": false, \"low_stock_threshold_units\": 30, \"confirm_sale_before_commit\": true, \"expiry_alert_critical_days\": 7, \"scanner_auto_submit_on_ean\": false}','2026-03-02 14:21:34');

SET foreign_key_checks = 1;
