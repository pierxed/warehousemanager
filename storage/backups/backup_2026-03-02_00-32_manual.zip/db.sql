SET NAMES utf8mb4;
SET foreign_key_checks = 0;

-- Table: `batches`
DROP TABLE IF EXISTS `batches`;
CREATE TABLE `batches` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fish_type` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `lot_number` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `production_date` date NOT NULL,
  `expiration_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lot_number` (`lot_number`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `batches` (`id`,`fish_type`,`lot_number`,`production_date`,`expiration_date`,`created_at`) VALUES (26,'TONNO',28.26,'2026-03-01','2030-02-28','2026-03-01 02:10:43');
INSERT INTO `batches` (`id`,`fish_type`,`lot_number`,`production_date`,`expiration_date`,`created_at`) VALUES (27,'TONNO',22.26,'2026-03-01','2030-02-22','2026-03-01 02:12:28');
INSERT INTO `batches` (`id`,`fish_type`,`lot_number`,`production_date`,`expiration_date`,`created_at`) VALUES (28,'TONNO',12.26,'2026-03-01','2026-03-12','2026-03-01 02:40:14');
INSERT INTO `batches` (`id`,`fish_type`,`lot_number`,`production_date`,`expiration_date`,`created_at`) VALUES (29,'TONNO',24.26,'2026-03-01','2030-02-21','2026-03-01 20:22:39');
INSERT INTO `batches` (`id`,`fish_type`,`lot_number`,`production_date`,`expiration_date`,`created_at`) VALUES (30,'SGOMBRO',43.26,'2026-03-01','2026-03-31','2026-03-01 21:33:24');
INSERT INTO `batches` (`id`,`fish_type`,`lot_number`,`production_date`,`expiration_date`,`created_at`) VALUES (31,'SGOMBRO',43.262,'2026-03-01','2026-03-31','2026-03-01 22:48:43');
INSERT INTO `batches` (`id`,`fish_type`,`lot_number`,`production_date`,`expiration_date`,`created_at`) VALUES (32,'TONNO',100,'2026-03-02','2026-03-06','2026-03-02 00:44:26');
INSERT INTO `batches` (`id`,`fish_type`,`lot_number`,`production_date`,`expiration_date`,`created_at`) VALUES (33,'TONNO',101,'2026-03-02','2026-03-12','2026-03-02 00:44:43');
INSERT INTO `batches` (`id`,`fish_type`,`lot_number`,`production_date`,`expiration_date`,`created_at`) VALUES (34,'TONNO',102,'2026-03-02','2026-03-02','2026-03-02 00:46:01');
INSERT INTO `batches` (`id`,`fish_type`,`lot_number`,`production_date`,`expiration_date`,`created_at`) VALUES (35,'TONNO',103,'2026-03-02','2026-03-01','2026-03-02 00:46:10');
INSERT INTO `batches` (`id`,`fish_type`,`lot_number`,`production_date`,`expiration_date`,`created_at`) VALUES (36,'SGOMBRO',3232,'2026-03-02','2026-02-25','2026-03-02 00:46:55');

-- Table: `lots`
DROP TABLE IF EXISTS `lots`;
CREATE TABLE `lots` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `batch_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id` (`product_id`,`batch_id`),
  KEY `batch_id` (`batch_id`),
  CONSTRAINT `lots_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `lots_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `batches` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `lots` (`id`,`product_id`,`batch_id`,`created_at`) VALUES (41,38,26,'2026-03-01 02:10:43');
INSERT INTO `lots` (`id`,`product_id`,`batch_id`,`created_at`) VALUES (42,38,27,'2026-03-01 02:12:28');
INSERT INTO `lots` (`id`,`product_id`,`batch_id`,`created_at`) VALUES (43,38,28,'2026-03-01 02:40:14');
INSERT INTO `lots` (`id`,`product_id`,`batch_id`,`created_at`) VALUES (44,38,29,'2026-03-01 20:22:39');
INSERT INTO `lots` (`id`,`product_id`,`batch_id`,`created_at`) VALUES (45,39,30,'2026-03-01 21:33:24');
INSERT INTO `lots` (`id`,`product_id`,`batch_id`,`created_at`) VALUES (46,39,31,'2026-03-01 22:48:43');
INSERT INTO `lots` (`id`,`product_id`,`batch_id`,`created_at`) VALUES (47,38,32,'2026-03-02 00:44:26');
INSERT INTO `lots` (`id`,`product_id`,`batch_id`,`created_at`) VALUES (48,38,33,'2026-03-02 00:44:43');
INSERT INTO `lots` (`id`,`product_id`,`batch_id`,`created_at`) VALUES (49,38,34,'2026-03-02 00:46:01');
INSERT INTO `lots` (`id`,`product_id`,`batch_id`,`created_at`) VALUES (50,38,35,'2026-03-02 00:46:10');
INSERT INTO `lots` (`id`,`product_id`,`batch_id`,`created_at`) VALUES (51,39,36,'2026-03-02 00:46:55');

-- Table: `movements`
DROP TABLE IF EXISTS `movements`;
CREATE TABLE `movements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `lot_id` int NOT NULL,
  `quantity` int NOT NULL,
  `type` enum('PRODUCTION','SALE','ADJUSTMENT') COLLATE utf8mb4_general_ci NOT NULL,
  `reason` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `note` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `lot_id` (`lot_id`),
  CONSTRAINT `movements_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `movements_ibfk_2` FOREIGN KEY (`lot_id`) REFERENCES `lots` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (1,38,41,144,'PRODUCTION',NULL,NULL,'2026-03-01 02:10:43');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (2,38,41,133,'PRODUCTION',NULL,NULL,'2026-03-01 02:11:58');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (3,38,42,133,'PRODUCTION',NULL,NULL,'2026-03-01 02:12:28');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (4,38,42,10,'SALE',NULL,NULL,'2026-03-01 02:12:46');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (5,38,42,12,'SALE',NULL,NULL,'2026-03-01 02:13:11');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (6,38,42,1,'SALE',NULL,NULL,'2026-03-01 02:13:21');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (7,38,41,1,'SALE',NULL,NULL,'2026-03-01 02:13:27');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (8,38,43,264,'PRODUCTION',NULL,NULL,'2026-03-01 02:40:14');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (9,38,43,-264,'ADJUSTMENT','ROTTURA',NULL,'2026-03-01 02:43:36');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (10,38,42,1,'SALE',NULL,NULL,'2026-03-01 02:46:48');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (11,38,42,1,'SALE',NULL,NULL,'2026-03-01 02:47:19');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (12,38,41,1,'SALE',NULL,NULL,'2026-03-01 02:47:47');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (13,38,42,1,'SALE',NULL,NULL,'2026-03-01 02:48:16');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (14,38,41,1333,'PRODUCTION',NULL,NULL,'2026-03-01 02:48:52');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (15,38,43,264,'PRODUCTION',NULL,NULL,'2026-03-01 02:52:25');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (16,38,41,12,'PRODUCTION',NULL,NULL,'2026-03-01 07:50:02');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (17,38,42,12,'PRODUCTION',NULL,NULL,'2026-03-01 07:50:06');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (18,38,41,12,'PRODUCTION',NULL,NULL,'2026-03-01 07:50:10');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (19,38,43,12,'PRODUCTION',NULL,NULL,'2026-03-01 07:50:13');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (20,38,42,12,'PRODUCTION',NULL,NULL,'2026-03-01 07:50:19');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (21,38,43,1,'SALE',NULL,NULL,'2026-03-01 07:50:34');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (22,38,43,1,'SALE',NULL,NULL,'2026-03-01 07:50:41');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (23,38,43,1,'SALE',NULL,NULL,'2026-03-01 07:51:20');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (24,38,43,1,'SALE',NULL,NULL,'2026-03-01 07:51:27');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (25,38,41,1,'PRODUCTION',NULL,NULL,'2026-03-01 07:51:44');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (26,38,41,1,'ADJUSTMENT','ROTTURA',NULL,'2026-03-01 07:51:59');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (27,38,41,1,'SALE',NULL,NULL,'2026-03-01 07:52:03');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (28,38,41,1,'ADJUSTMENT','ROTTURA',NULL,'2026-03-01 07:52:06');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (29,38,43,1,'PRODUCTION',NULL,NULL,'2026-03-01 07:56:21');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (30,38,41,1,'PRODUCTION',NULL,NULL,'2026-03-01 07:56:32');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (31,38,43,1,'SALE',NULL,NULL,'2026-03-01 09:24:31');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (32,38,43,1,'SALE',NULL,NULL,'2026-03-01 09:24:34');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (33,38,43,271,'SALE',NULL,NULL,'2026-03-01 19:03:32');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (34,38,42,1,'SALE',NULL,NULL,'2026-03-01 20:20:21');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (35,38,44,369,'PRODUCTION',NULL,NULL,'2026-03-01 20:22:39');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (36,38,43,369,'PRODUCTION',NULL,NULL,'2026-03-01 21:05:50');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (37,38,42,1,'SALE',NULL,NULL,'2026-03-01 21:05:58');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (38,38,43,-310,'ADJUSTMENT','ROTTURA',NULL,'2026-03-01 21:06:34');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (39,39,45,1,'PRODUCTION',NULL,NULL,'2026-03-01 21:33:24');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (40,39,45,1,'SALE',NULL,NULL,'2026-03-01 22:02:15');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (41,38,41,1,'SALE',NULL,NULL,'2026-03-01 22:02:24');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (42,38,44,1,'ADJUSTMENT','RESO','aaa','2026-03-01 22:29:14');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (43,39,46,36,'PRODUCTION',NULL,NULL,'2026-03-01 22:48:43');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (44,38,43,1,'SALE',NULL,NULL,'2026-03-01 22:49:46');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (45,38,43,1,'SALE',NULL,NULL,'2026-03-01 22:49:49');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (46,38,43,1,'SALE',NULL,NULL,'2026-03-01 22:49:54');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (47,38,43,1,'PRODUCTION',NULL,NULL,'2026-03-01 22:50:09');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (48,38,43,1,'SALE',NULL,NULL,'2026-03-01 22:50:23');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (49,38,44,-10,'ADJUSTMENT','ROTTURA',NULL,'2026-03-02 00:31:08');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (50,38,47,246,'PRODUCTION',NULL,NULL,'2026-03-02 00:44:26');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (51,38,48,246,'PRODUCTION',NULL,NULL,'2026-03-02 00:44:43');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (52,38,47,246,'PRODUCTION',NULL,NULL,'2026-03-02 00:44:51');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (53,38,49,123,'PRODUCTION',NULL,NULL,'2026-03-02 00:46:01');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (54,38,50,123,'PRODUCTION',NULL,NULL,'2026-03-02 00:46:10');
INSERT INTO `movements` (`id`,`product_id`,`lot_id`,`quantity`,`type`,`reason`,`note`,`created_at`) VALUES (55,39,51,12,'PRODUCTION',NULL,NULL,'2026-03-02 00:46:55');

-- Table: `products`
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `format` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `fish_type` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `ean` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `units_per_tray` int NOT NULL,
  `image_path` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ean` (`ean`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `products` (`id`,`name`,`format`,`fish_type`,`ean`,`units_per_tray`,`image_path`,`created_at`,`is_active`) VALUES (38,'Tonno Olio di olival','100gr','TONNO',8001234567891,123,NULL,'2026-03-01 02:10:13',1);
INSERT INTO `products` (`id`,`name`,`format`,`fish_type`,`ean`,`units_per_tray`,`image_path`,`created_at`,`is_active`) VALUES (39,'Sgombro olio d\'oliva',200,'SGOMBRO',800232,12,NULL,'2026-03-01 21:32:45',1);

-- Table: `settings`
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `settings_json` json NOT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `settings` (`id`,`settings_json`,`updated_at`) VALUES (1,'{\"backup_time\": \"02:00\", \"backup_enabled\": true, \"backup_frequency\": \"off\", \"backup_keep_last\": 14, \"backup_auto_prune\": true, \"expiry_alert_days\": 30, \"sale_default_mode\": \"FEFO\", \"backup_environment\": \"local\", \"backup_include_uploads\": true, \"low_stock_alert_enabled\": true, \"scanner_beep_on_success\": false, \"scanner_vibrate_on_error\": false, \"expiry_include_zero_stock\": false, \"low_stock_threshold_units\": 10, \"confirm_sale_before_commit\": true, \"scanner_auto_submit_on_ean\": false}','2026-03-02 01:31:46');

SET foreign_key_checks = 1;
